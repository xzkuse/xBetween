package com.abc.greendaotest;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.abc.bean.User;
import org.greenrobot.greendao.query.DeleteQuery;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * 项目构建时间偏慢
 *
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView txt_insert_one;
    private TextView txt_delete_one;
    private TextView txt_update_one;
    private TextView txt_search_one;
    private TextView txt_version_up;
    private TextView txt_insert_more;
    private TextView txt_search_page;
    private TextView txt_insert100_time_offect;

    /*
    search内容展示
     */
    private TextView txt_content;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_insert_one = findViewById(R.id.txt_insert_one);
        txt_delete_one = findViewById(R.id.txt_delete_one);
        txt_update_one = findViewById(R.id.txt_update_one);
        txt_search_one = findViewById(R.id.txt_search_one);
        txt_version_up = findViewById(R.id.txt_version_up);
        txt_insert_more = findViewById(R.id.txt_insert_more);
        txt_search_page = findViewById(R.id.txt_search_page);
        txt_insert100_time_offect = findViewById(R.id.txt_insert100_time_offect);
        txt_content = findViewById(R.id.txt_content);
        setOnClick(txt_insert_one,txt_delete_one,txt_update_one,txt_search_one
            ,txt_version_up,txt_insert_more,txt_search_page
            ,txt_insert100_time_offect);
    }

    private  int offect=0;
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_insert_one:
                User user = new User();
                user.setName("张三");
//                user.setPrice(30.02f);
                user.setGander(true);
                user.setYear(1999);
                long orReplace = GreenDaoManager.getInstance().getmDaoSession().getUserDao().insertOrReplace(user);
                Log.d("tags", "添加成功:" + orReplace);
                break;
            case  R.id.txt_delete_one:
                QueryBuilder<User> builder = GreenDaoManager.getInstance().getmDaoSession().getUserDao()
                                                                     .queryBuilder();
                QueryBuilder<User> queryBuilder = builder.where(UserDao.Properties.Year.eq(1999));
                DeleteQuery<User> deleteQuery = queryBuilder.buildDelete();
                deleteQuery.executeDeleteWithoutDetachingEntities();
                Log.d("tags","删除了:");
                break;
            case  R.id.txt_update_one:
                List<User> users = GreenDaoManager.getInstance().getmDaoSession().getUserDao().queryBuilder()
                                                  .where(UserDao.Properties.Year.eq(1999)).list();
                for (int i = 0; i < users.size(); i++) {
                    users.get(i).setYear(4000);
                    users.get(i).setGander(false);
                }
               GreenDaoManager.getInstance().getmDaoSession().getUserDao().updateInTx(users);
                Log.d("tags", "修改结果:");
                break;
            case R.id.txt_search_one:
                //查看表升级之后，是否能正常进入app，并不显示year，而是显示 gander year  支持
                List<User> users1 = GreenDaoManager.getInstance().getmDaoSession().getUserDao().loadAll();
                StringBuilder sbr=new StringBuilder();
                sbr.append(System.currentTimeMillis()+"\n");
                for (int i = 0; i < users1.size(); i++) {
                    sbr.append(users1.get(i).toString());
                }
                txt_content.setText(sbr.toString());
                break;
            case  R.id.txt_version_up:
                Log.d("tags","升级：库变化,"+"降级：Can't downgrade database from version 2 to 1");
                break;
            case R.id.txt_insert_more:
                List<User> userList=new ArrayList<>();
                for (int i = 0; i < 10; i++) {
                    User user1=new User();
                    user1.setName((i%2==1) ? "张望":"褐色");
                    user1.setGander((i%2==1) ? true:false);
                    user1.setYear((i%2==1) ? 1000:1456);
                    userList.add(user1);
                }
                GreenDaoManager.getInstance().getmDaoSession().getUserDao().updateInTx(userList);
                break;
            case  R.id.txt_search_page:
                QueryBuilder<User> userQueryBuilder = GreenDaoManager.getInstance().getmDaoSession().getUserDao()
                                                                     .queryBuilder();
                List<User> userList1 = userQueryBuilder.limit(10).offset(offect).list();
                Log.d("tags","偏移量offect："+offect++);
                StringBuilder sbruserList=new StringBuilder();
                for (int i = 0; i < userList1.size(); i++) {
                    sbruserList.append(userList1.get(i).toString());
                }
                txt_content.setText(sbruserList.toString());
                //分页查询最后会查出0个值
                break;
            case R.id.txt_insert100_time_offect:
                GreenDaoManager.getInstance().getmDaoSession().getUserDao().deleteAll();
                long l1 = System.currentTimeMillis();
                List<User> userList2=new ArrayList<>();
                for (int i = 0; i < 100; i++) {
                    User user1=new User();
                    user1.setName((i%2==1) ? "张望":"褐色");
                    user1.setGander((i%2==1) ? true:false);
                    user1.setYear((i%2==1) ? 1000:1456);
                    userList2.add(user1);
                }
                GreenDaoManager.getInstance().getmDaoSession().getUserDao().insertInTx(userList2);
//                Cannot update entity without key - was it inserted before
//                updateInTx()  方法时，主键为null，不能更新
                List<User> all1 = GreenDaoManager.getInstance().getmDaoSession().getUserDao().loadAll();
                long l2 = System.currentTimeMillis();
                Log.d("tags","查询-->"+all1.size()+"总计时差："+(l2-l1));
                //查询-->100总计时差：16   查询-->100总计时差：12   查询-->100总计时差：12   查询-->100总计时差：11  查询-->100总计时差：12
                break;
            default:
                Log.d("tags", "view未注册");
                break;
        }
    }
    private void setOnClick(View... views) {
        for (View view : views) {
            view.setOnClickListener(this);
        }
    }
}
