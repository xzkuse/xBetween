package com.abc.greendaotest;

import android.app.Application;

/**
 * @author xzk
 * @data 2018/9/3
 * @email o-xiezhengkun@beyondsoft.com
 * @remark
 */
public class App extends Application {

    private static App application;

    @Override
    public void onCreate() {
        super.onCreate();
        application=this;
        //GreenDao的初始化
        GreenDaoManager.getInstance();
    }

//    private static DaoSession daoSession;
//
//    /**
//     * 配置数据库
//     */
//    private void setupDatabase() {
//        //创建数据库shop.db"
//        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "shop.db", null);
//        //获取可写数据库
//        SQLiteDatabase db = helper.getWritableDatabase();
//        //获取数据库对象
//        DaoMaster daoMaster = new DaoMaster(db);
//        //获取Dao对象管理者
//        daoSession = daoMaster.newSession();
//    }
//
//    public static DaoSession getDaoInstant() {
//        return daoSession;
//    }

    public static App getmAppContext(){
        return application;
    }
}
