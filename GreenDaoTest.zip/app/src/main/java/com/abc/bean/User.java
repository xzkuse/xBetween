package com.abc.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Keep;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author xzk
 * @data 2018/8/31
 * @email o-xiezhengkun@beyondsoft.com
 * @remark  用户表
 */
@Entity
public class User{

    @Id(autoincrement = true)
    private Long id;

//自增主键id
    private String name;

    //  version = 1
//    private float price;


    //version = 2
    private boolean gander;
    private Integer year;

    @Keep
    public User() {
    }

    @Generated(hash = 94119818)
    public User(Long id, String name, boolean gander, Integer year) {
        this.id = id;
        this.name = name;
        this.gander = gander;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public float getPrice() {
//        return price;
//    }
//
//    public void setPrice(float price) {
//        this.price = price;
//    }
//    @Keep
//    public User(Long id, String name, float price) {
//        this.id = id;
//        this.name = name;
//        this.price = price;
//    }

//    @Override
//    public String toString() {
//        return "User{" + "id=" + id + ", name='" + name + '\'' + ", price=" + price + '}';
//    }
        public boolean isGander() {
        return gander;
    }

    public void setGander(boolean gander) {
        this.gander = gander;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "User{" + "name='" + name + '\'' + ", gander=" + gander + ", year=" + year + '}';
    }

    public boolean getGander() {
        return this.gander;
    }
}
