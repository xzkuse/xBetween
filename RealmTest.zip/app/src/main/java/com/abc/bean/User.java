package com.abc.bean;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * @author xzk
 * @data 2018/8/31
 * @email o-xiezhengkun@beyondsoft.com
 * @remark  用户表
 */
public class User extends RealmObject {
    // io.realm.exceptions.RealmException: 'User' has a primary key, use 'createObject(Class<E>, Object)' instead.
    //有主键时，需要使用  realm.createObject(User.class，1);  对主键进行赋值
//    @PrimaryKey
    private Long id;//更换主键非常麻烦，删除或者修改都报错，建议无必要情况，不更换主键
//    class_User has no primary key defined.
//自增主键id

    private String name;

    //  version = 1
//    private float price;
//    realm Property 'User.year' has been made optional   mode未定义的意义吧

    //version = 2
    private boolean gander;
    private Integer year;
//    Migration is required due to the following errors:
//        - Property 'User.year' has been added.
//    - Property 'User.gander' has been added.
//    - Property 'User.price' has been removed.

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public float getPrice() {
//        return price;
//    }
//
//    public void setPrice(float price) {
//        this.price = price;
//    }
//
//    @Override
//    public String toString() {
//        return "User{" + "id=" + id + ", name='" + name + '\'' + ", price=" + price + '}';
//    }

    public boolean isGander() {
        return gander;
    }

    public void setGander(boolean gander) {
        this.gander = gander;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "User{" + "name='" + name + '\'' + ", gander=" + gander + ", year=" + year + '}';
    }

}
