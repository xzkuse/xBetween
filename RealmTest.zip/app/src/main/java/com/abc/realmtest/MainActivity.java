package com.abc.realmtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.abc.bean.User;
import io.realm.Realm;
import io.realm.RealmModel;
import io.realm.RealmResults;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView txt_insert_one;
    private TextView txt_delete_one;
    private TextView txt_update_one;
    private TextView txt_search_one;
    private TextView txt_version_up;
    private TextView txt_insert_more;
    private TextView txt_search_page;
    private TextView txt_insert100_time_offect;

    /*
    search内容展示
     */
    private TextView txt_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_insert_one = findViewById(R.id.txt_insert_one);
        txt_delete_one = findViewById(R.id.txt_delete_one);
        txt_update_one = findViewById(R.id.txt_update_one);
        txt_search_one = findViewById(R.id.txt_search_one);
        txt_version_up = findViewById(R.id.txt_version_up);
        txt_insert_more = findViewById(R.id.txt_insert_more);
        txt_search_page = findViewById(R.id.txt_search_page);
        txt_insert100_time_offect = findViewById(R.id.txt_insert100_time_offect);
        txt_content = findViewById(R.id.txt_content);
        setOnClick(txt_insert_one, txt_delete_one, txt_update_one, txt_search_one, txt_version_up, txt_insert_more,
                   txt_search_page, txt_insert100_time_offect);
    }

    private int offect = 0;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_insert_one: {
                //                Realm realm = Realm.getInstance(App.getRealmConfiguration());
                // 升级之后必须使用增加了 RealmConfiguration 的realm对象，否则爆异常
                Realm realm = Realm.getDefaultInstance();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        User user = realm.createObject(User.class);
                        user.setName("张三");
                        //                        user.setPrice(30.02f);
                        user.setGander(true);
                        user.setYear(1999);
                        Log.d("tags", "添加结果:");
                    }
                });
            }
            break;
            case R.id.txt_delete_one: {
                //                Realm realm = Realm.getInstance(App.getRealmConfiguration());
                Realm realm = Realm.getDefaultInstance();
                //先查找到数据
                final RealmResults<User> userList = realm.where(User.class).equalTo("year", 1999).findAll();
                //                final RealmResults<User> userList = realm.where(User.class).equalTo("price",30.02f).findAll();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        boolean allFromRealm = userList.deleteAllFromRealm();
                        Log.d("tags", "删除了:" + allFromRealm);
                        //                        userList.get(4).deleteFromRealm();//删除指定位置（第4条记录）的记录
                        //                        userList.deleteFromRealm(4);//删除指定位置（第4条记录）的记录
                        //                        userList.deleteFirstFromRealm(); //删除user表的第一条数据
                        //                        userList.deleteLastFromRealm();//删除user表的最后一条数据
                        //                        userList.deleteAllFromRealm();//删除user表的全部数据
                    }
                });
            }
            break;
            case R.id.txt_update_one: {
                //                final Realm realm = Realm.getInstance(App.getRealmConfiguration());
                final Realm realm = Realm.getDefaultInstance();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realms) {
                        //先查找后得到User对象
                        //                        RealmResults<User> users = realm.where(User.class).equalTo("price",30.02f)
                        //                                                        .equalTo("name", "张三").findAll();
                        RealmResults<User> users = realm.where(User.class).equalTo("year", 1999).equalTo("name", "张三")
                                                        .findAll();
                        for (User user : users) {
                            //                            user.setPrice(40.02f);
                            user.setYear(4000);
                            user.setGander(false);
                        }
                        Log.d("tags", "修改结果:");
                    }
                });
            }
            break;
            case R.id.txt_search_one:
                //查看表升级之后，是否能正常进入app，并不显示year，而是显示 gander year  支持
            {
                Realm realm = Realm.getDefaultInstance();
                //                Realm realm = Realm.getInstance(App.getRealmConfiguration());
                RealmResults<User> users = realm.where(User.class).findAll();
                StringBuilder sbr = new StringBuilder();
                sbr.append(System.currentTimeMillis() + "\n");
                for (int i = 0; i < users.size(); i++) {
                    sbr.append(users.get(i).toString());
                }
                txt_content.setText(sbr.toString());
            }
            break;
            case R.id.txt_version_up:
                //io.realm.exceptions.RealmMigrationNeededException: Migration is required due to the following errors:
                //                由于以下错误，需要进行迁移:
                //                - Property 'User.year' has been added.
                //                - Property 'User.gander' has been added.
                //                - Property 'User.price' has been removed.
                Log.d("tags", "升 级：库变化," + "降级： Provided schema version 1 is less than last set version 2.");
                break;
            case R.id.txt_insert_more: {
                Realm realm = Realm.getDefaultInstance();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        for (int i = 0; i < 10; i++) {
                            User user1 = realm.createObject(User.class);
                            user1.setName((i % 2 == 1) ? "张望" : "褐色");
                            user1.setGander((i % 2 == 1) ? true : false);
                            user1.setYear((i % 2 == 1) ? 1000 : 1456);
                        }
                        Log.d("tags", "添加结果:");
                    }
                });
            }
            break;
            case R.id.txt_search_page: {
                Realm realm = Realm.getDefaultInstance();
                RealmResults<User> users = realm.where(User.class).findAll();
                List<User> limitList = getLimitList(users, offect, 10);
                StringBuilder sbr = new StringBuilder();
                sbr.append(System.currentTimeMillis() + "\n");
                for (int i = 0; i < limitList.size(); i++) {
                    sbr.append(limitList.get(i).toString());
                }
                txt_content.setText(sbr.toString());
                Log.d("tags", "偏移量offect：" + offect++);
                //分页查询最后会查出0个值
            }
            break;
            case R.id.txt_insert100_time_offect: {
                Realm realm = Realm.getDefaultInstance();
                final RealmResults<User> userList = realm.where(User.class).findAll();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        boolean allFromRealm = userList.deleteAllFromRealm();
                        Log.d("tags", "删除所有:"+allFromRealm);
                    }
                });
                long l1 = System.currentTimeMillis();
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        for (int i = 0; i < 100; i++) {
                            User user1 = realm.createObject(User.class);
                            user1.setName((i % 2 == 1) ? "张望" : "褐色");
                            user1.setGander((i % 2 == 1) ? true : false);
                            user1.setYear((i % 2 == 1) ? 1000 : 1456);
                        }
                        Log.d("tags", "添加结果:");
                    }
                });
                RealmResults<User> users = realm.where(User.class).findAll();
                long l2 = System.currentTimeMillis();
                Log.d("tags", "查询-->" + users.size() + "总计时差：" + (l2 - l1));
                // 查询-->100总计时差：11  查询-->100总计时差：8    查询-->100总计时差：7  查询-->100总计时差：8   查询-->100总计时差：6
            }
            break;
            default:
                Log.d("tags", "view未注册");
                break;
        }
    }

    //分页查询
    public static <E extends RealmModel> List<E> getLimitList(RealmResults<E> data, int offset, int limit) {
        List<E> obtainList = new ArrayList();
        Realm realm = Realm.getDefaultInstance();
        if (data.size() == 0) {
            return obtainList;
        }
        for (int i = offset; i < offset + limit; i++) {
            if (i >= data.size()) {
                break;
            }
            E temp = realm.copyFromRealm(data.get(i));
            obtainList.add(temp);
        }
        realm.close();
        return obtainList;
    }

    private void setOnClick(View... views) {
        for (View view : views) {
            view.setOnClickListener(this);
        }
    }
}
