package com.abc.realmtest;

import android.app.Application;
import android.content.Context;
import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * @author xzk
 * @data 2018/9/3
 * @email o-xiezhengkun@beyondsoft.com
 * @remark
 */
public class App extends Application {

    private static RealmConfiguration config;
    private static App instance;

    @Override
    public void onCreate() {
        super.onCreate();
        //Unable to create application com.abc.realmtest.App: java.lang.IllegalStateException: Call `Realm.init(Context)` before creating a RealmConfiguration
        Realm.init(this);
        instance=this;

        config = new RealmConfiguration.Builder()
            .name("realm.db") //文件名
            .schemaVersion(2) //版本号
            .migration(new CustomMigration())
            .build();

        //升级之后必须使用增加了 RealmConfiguration 的realm对象，否则爆异常  - Property 'User.year' has been added.
        //        Realm realm = Realm.getInstance(config);
        //测试：是否只需要在这里初始化一次即可   ：结果，可行  做一次初始化即可
                Realm.setDefaultConfiguration(config);
    }

    public static Context getInstance() {
        return instance;
    }

    public static RealmConfiguration getRealmConfiguration() {
        return config;
    }

}
