package com.abc.realmtest;

import android.util.Log;
import io.realm.*;

/**
 * @author xzk
 * @data 2018/9/3
 * @email o-xiezhengkun@beyondsoft.com
 * @remark  升级相对复杂，需要对类的变化做详细记录   升级不能顺利使用
 */
public class CustomMigration implements RealmMigration {
    @Override
    public void migrate(final DynamicRealm realm, long oldVersion, long newVersion) {
        RealmSchema schema = realm.getSchema();
        Log.d("tags","oldVersion:"+oldVersion);
        Log.d("tags","newVersion:"+newVersion);
        if (oldVersion == 1 && newVersion == 2) {
            RealmObjectSchema personSchema = schema.get("User");
            //新增@Required的id
            personSchema.removeField("price")
                .addField("gander", boolean.class)//增加 gander 属性   boolean不能用 Boolean
                .addField("year", Integer.class)
                .transform(new RealmObjectSchema.Function() {
                    @Override
                    public void apply(DynamicRealmObject dynamicRealmObject) {
                        //为已存在的数据设置user数据
                        DynamicRealmObject user = realm.createObject("User");
                        user.setBoolean("gander",true);
                        user.setInt("year",2000);
                        user.setString("name","up up");
                    }
                });//移除age属性
            oldVersion++;
        }
    }
}
