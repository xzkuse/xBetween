package com.abc.bean;

import org.litepal.crud.LitePalSupport;

/**
 * @author xzk
 * @data 2018/8/31
 * @email o-xiezhengkun@beyondsoft.com
 * @remark  用户表
 */
public class User extends LitePalSupport{

//自增主键id
    private String name;

    //  version = 1
//    private float price;


    //version = 2
    private boolean gander;
    private Integer year;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isGander() {
        return gander;
    }

    public void setGander(boolean gander) {
        this.gander = gander;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "User{" + "name='" + name + '\'' + ", gander=" + gander + ", year=" + year + '}';
    }
}
