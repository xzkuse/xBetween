package com.abc.litepaltest;

import android.app.Application;
import org.litepal.LitePal;

/**
 * @author xzk
 * @data 2018/8/31
 * @email o-xiezhengkun@beyondsoft.com
 * @remark  基础获取压缩
 */
public class TestApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        LitePal.initialize(this);
    }
}
