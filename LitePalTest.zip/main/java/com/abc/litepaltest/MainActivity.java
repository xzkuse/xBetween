package com.abc.litepaltest;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.abc.bean.User;
import org.litepal.FluentQuery;
import org.litepal.LitePal;
import org.litepal.crud.DataSupport;
import org.litepal.crud.LitePalSupport;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView txt_insert_one;
    private TextView txt_delete_one;
    private TextView txt_update_one;
    private TextView txt_search_one;
    private TextView txt_version_up;
    private TextView txt_insert_more;
    private TextView txt_search_page;
    private TextView txt_insert100_time_offect;
    /*
    search内容展示
     */
    private TextView txt_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_insert_one = findViewById(R.id.txt_insert_one);
        txt_delete_one = findViewById(R.id.txt_delete_one);
        txt_update_one = findViewById(R.id.txt_update_one);
        txt_search_one = findViewById(R.id.txt_search_one);
        txt_version_up = findViewById(R.id.txt_version_up);
        txt_insert_more = findViewById(R.id.txt_insert_more);
        txt_search_page = findViewById(R.id.txt_search_page);
        txt_insert100_time_offect = findViewById(R.id.txt_insert100_time_offect);
        txt_content = findViewById(R.id.txt_content);
        setOnClick(txt_insert_one,txt_delete_one,txt_update_one,txt_search_one
                   ,txt_version_up,txt_insert_more,txt_search_page
                  ,txt_insert100_time_offect);
    }

private  int offect=0;
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txt_insert_one:
                User user = new User();
                user.setName("张三");
                user.setGander(true);
                user.setYear(1999);
                boolean save = user.save();
                Log.d("tags","添加成功:"+save);
                break;
            case  R.id.txt_delete_one:
                int all = LitePal.deleteAll(User.class, "year = ?", "1999");
                Log.d("tags","删除成功:"+all);
                break;
            case  R.id.txt_update_one:
                ContentValues contentValues=new ContentValues();
                contentValues.put("year",2018);
                int updateAll = LitePal.updateAll(User.class, contentValues, new String[]{"year = ?", "1999"});
                Log.d("tags","修改成功:"+updateAll);
                break;
            case R.id.txt_search_one:
                //查看表升级之后，是否能正常进入app，并不显示year，而是显示 gander year  支持
                List<User> users = LitePal.findAll(User.class);
                StringBuilder sbr=new StringBuilder();
                for (int i = 0; i < users.size(); i++) {
                    sbr.append(users.get(i).toString());
                }
                txt_content.setText(sbr.toString());
                break;
            case  R.id.txt_version_up:
                Log.d("tags","升级：库变化,"+"降级：the version in litepal.xml is earlier than the current version");
                break;
            case R.id.txt_insert_more:
                for (int i = 0; i < 10; i++) {
                    User user1=new User();
                    user1.setName((i%2==1) ? "张望":"褐色");
                    user1.setGander((i%2==1) ? true:false);
                    user1.setYear((i%2==1) ? 1000:1456);
                    user1.save();
                }
                break;
            case  R.id.txt_search_page:
                List<User> userList = LitePal.limit(10).offset(offect).find(User.class);
//                List<News> newsList = DataSupport.select("title", "content")
//                                                 .where("commentcount > ?", "0")
//                                                 .order("publishdate desc").limit(10).offset(10)
                Log.d("tags","偏移量offect："+offect++);
                StringBuilder sbruserList=new StringBuilder();
                for (int i = 0; i < userList.size(); i++) {
                    sbruserList.append(userList.get(i).toString());
                }
                txt_content.setText(sbruserList.toString());
                //分页查询最后会查出0个值
                break;
            case R.id.txt_insert100_time_offect:
                LitePal.deleteAll(User.class);
                long l1 = System.currentTimeMillis();
                for (int i = 0; i < 100; i++) {
                    User user1=new User();
                    user1.setName((i%2==1) ? "张望":"褐色");
                    user1.setGander((i%2==1) ? true:false);
                    user1.setYear((i%2==1) ? 1000:1456);
                    user1.save();
                }
                List<User> all1 = LitePal.findAll(User.class);
                long l2 = System.currentTimeMillis();
                Log.d("tags","查询-->"+all1.size()+"总计时差："+(l2-l1));
                // 查询-->100总计时差：602  查询-->100总计时差：667   查询-->100总计时差：683   查询-->100总计时差：629  查询-->100总计时差：659
                break;
            default:
                Log.d("tags", "view未注册");
                break;
        }
    }

    private void setOnClick(View... views) {
        for (View view : views) {
            view.setOnClickListener(this);
        }
    }
}
